#!/bin/bash

#########################################################
# Author: Vani Singamsetty
# Purpose: Partition the disk and created elkdata folder
# Usage Ex ./disk_partition.sh 50GB
#########################################################

diskspace=$1
diskname=`lsblk | grep disk | grep $diskspace | cut -d' ' -f1 | grep sd`
diskpart="${diskname}1"

if lsblk | grep -q ${diskpart}
then
   echo "/dev/${diskpart} partition already completed"
else
   sudo parted /dev/${diskname} --script mklabel gpt mkpart xfspart xfs 0% 100%
   if [ $? -eq 0 ]
   then
        echo "Created the partition successfully."
   else
         echo "Error while creating partition"
         exit 1
   fi
   sleep 4
   sudo mkfs.xfs /dev/${diskpart}
   sleep 2
   sudo partprobe /dev/${diskpart}
fi

lsblk

sed -i '/elkdata/d' /etc/fstab

diskuid=`blkid | grep /dev/${diskpart} | cut -d' ' -f2 | sed 's/\"//g'`
#diskuid=`blkid | grep /dev/${diskpart} | cut -d'=' -f3 | sed 's/\"//g'`

if grep -q "${diskuid}" "/etc/fstab"
then 
   echo "Entry in fastab exists."
else
   echo "${diskuid}       /elkdata  xfs defaults,nofail 0 0" | sudo tee -a /etc/fstab
fi

if [ -d "/elkdata" ]
then
  sudo mount /dev/${diskpart} /elkdata
else 
   mkdir /elkdata
   sudo mount /dev/${diskpart} /elkdata
fi

chmod -R 755 /elkdata

exit 0


